from django.db import models

# Create your models here.
class contactus(models.Model):
    Name=models.CharField(max_length=100)
    Email=models.CharField(max_length=40)
    Mobile=models.CharField(max_length=30)
    Message=models.TextField()
    def __str__(self):
        return self.Name

####################################################################

class slider(models.Model):
    shead=models.CharField(max_length=300)
    ssubject=models.CharField(max_length=300)
    sdes=models.TextField()
    spic=models.ImageField(upload_to='static/slider',default="")

    def __str__(self):
        return self.shead
###############################################################################
class igallery(models.Model):
    gname=models.CharField(max_length=400)
    gpic=models.ImageField(upload_to='static/gallery/',default="")

    def __str__(self):
        return self.gname

#############################################################################
class vgallery(models.Model):
    vname=models.CharField(max_length=400)
    vid=models.FileField(upload_to='static/videos/',default="")
    poster=models.ImageField(upload_to='static/videos/posters',default="")

    def __str__(self):
        return self.vname

#############################################################################

class vidgallery(models.Model):
    vtitle=models.CharField(max_length=100)
    vdes=models.TextField()
    vdate=models.DateField()
    vidlink=models.TextField()

    def __str__(self):
        return self.vtitle

#############################################################################

class myblog(models.Model):
    bname=models.CharField(max_length=50)
    bdes=models.TextField()
    bpic=models.ImageField(upload_to='static/blog_images/',default="")
    bdate=models.DateField()

    def __str__(self):
        return self.bname

###############################################################################

class ncity(models.Model):
    cname=models.CharField(max_length=60)

    def __str__(self):
        return self.cname

class member(models.Model):
    fname=models.CharField(max_length=60)
    lname=models.CharField(max_length=60)
    email=models.CharField(max_length=60)
    mobile=models.CharField(max_length=60)
    city=models.CharField(max_length=60)
    state=models.CharField(max_length=60)
    country=models.CharField(max_length=60)
    address=models.TextField()
    companyaddress=models.TextField()
    pincode=models.IntegerField()
    account=models.CharField(max_length=60)
    ifsc=models.CharField(max_length=60)
    ppic=models.ImageField(upload_to="static/membersprofile/",null=True)

    def __str__(self):
        return self.fname

class loginme(models.Model):
    mobile=models.CharField(max_length=60)
    password=models.CharField(max_length=100)

    def __str__(self):
        return self.mobile

class signup(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    mobile=models.IntegerField()
    password=models.CharField(max_length=100)
    confirmpassword=models.CharField(max_length=100)

    def __str__(self):
        return self.name

class event(models.Model):
    etitle=models.CharField(max_length=100)
    esubject=models.CharField(max_length=100)
    edate=models.DateField()
    epic=models.ImageField(upload_to='static/event/',default="")

    def __str__(self):
        return self.etitle

class volunteers(models.Model):
    volunteername=models.CharField(max_length=100)
    volunteerpost=models.CharField(max_length=100)
    volunteerpic=models.ImageField(upload_to='static/volunteers/',default="")

    def __str__(self):
        return self.volunteername

class donateus(models.Model):
    fname=models.CharField(max_length=100)
    lname=models.CharField(max_length=100)
    mobile=models.IntegerField()
    email=models.CharField(max_length=100)
    donation=models.IntegerField()
    address=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    country=models.CharField(max_length=100)
    occupation=models.CharField(max_length=100)
    pincode=models.CharField(max_length=100)
    city=models.CharField(max_length=100)
    screenshot=models.ImageField(upload_to='static/donateus/payment_screenshots',null=True)

    def __str__(self):
        return self.fname

class myprofile(models.Model):
    myname=models.CharField(max_length=200)
    college=models.CharField(max_length=200)
    course=models.CharField(max_length=200)
    myid=models.CharField(max_length=200)
    mybackground=models.ImageField(upload_to='static/myprofile/background',default="")
    mypic=models.ImageField(upload_to='static/myProfile/',default="")

    def __str__(self):
        return self.myname

class promise(models.Model):
    ptitle=models.CharField(max_length=200)
    ppic=models.ImageField(upload_to='static/promises/')

    def __str__(self):
        return self.ptitle

class compaign(models.Model):
    mycompaign=models.CharField(max_length=50)

    def __str__(self):
        return self.mycompaign

class newsletter(models.Model):
    subscribers=models.CharField(max_length=100)
