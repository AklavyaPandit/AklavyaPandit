from django.shortcuts import render
from .models import *
from django.db.models import Q
from django.http import HttpResponse

# Create your views here.
def index(request):
    s = slider.objects.all().order_by('-id')[0:2]
    mb = myblog.objects.all().order_by('-id')[0:3]
    et = event.objects.all().order_by('-id')[0:3]
    index = igallery.objects.all().order_by('-id')
    Promise = promise.objects.all().order_by('-id')[0:4]
    sdict = {"sli": s, "bdata": mb,"evt":et,"index":index,"promise":Promise}
    return render(request,'user/index.html',context=sdict)

##################################################
def about(request):
    return render(request,'user/about.html')

##################################################
def gallery(request):
    d = igallery.objects.all().order_by('-id')

    mydict = {"data": d}
    return render(request,'user/gallery.html',context=mydict)


##################################################
def contact(request):
    status=False
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        mobile=request.POST.get('mob')
        message=request.POST.get('msg')
        contactus(Name=name,Email=email,Mobile=mobile,Message=message).save()
        status=True
    return render(request,'user/contact.html',context={"msg":status})

##################################################
def video(request):
    v = vgallery.objects.all().order_by('-id')
    vid = vidgallery.objects.all().order_by('-id')
    mydict = {"data": v,"vid":vid}
    return render(request, 'user/video.html',mydict)

def videodetails(request):
    y=request.GET.get('msg')
    dt = vidgallery.objects.all().filter(id=y)
    thisdict = {"details":dt}
    return render(request,'user/details.html',thisdict)

##################################################
def donate(request):
    if request.method=="POST":
        fname=request.POST.get('fname')
        lname=request.POST.get('lname')
        email=request.POST.get('email')
        mobile=request.POST.get('mob')
        donation=request.POST.get('donation_amount')
        city=request.POST.get('city')
        state=request.POST.get('state')
        country=request.POST.get('country')
        pincode=request.POST.get('pincode')
        address=request.POST.get('address')
        occupation=request.POST.get('occupation')
        ss=request.POST.get('ss')
        donateus(fname=fname,lname=lname,email=email,mobile=mobile,donation=donation,city=city,state=state,country=country,pincode=pincode,address=address,occupation=occupation,screenshot=ss).save()
    return render(request,'user/donate.html')

##################################################
def membership(request):
    cities=ncity.objects.all().order_by('id')
    mydict={"ct":cities}
    if request.method=="POST":
        finame=request.POST.get('finame')
        laname=request.POST.get('laname')
        email=request.POST.get('email')
        number=request.POST.get('mob')
        add1=request.POST.get('city')
        add2=request.POST.get('state')
        add3=request.POST.get('country')
        address=request.POST.get('address')
        Caddress=request.POST.get('caddress')
        pincode=request.POST.get('pincode')
        account=request.POST.get('account')
        ifsc=request.POST.get('ifsc')
        ppic=request.FILES.get('file')
        member(fname=finame,lname=laname,email=email,mobile=number,city=add1,state=add2,country=add3,address=address,companyaddress=Caddress,pincode=pincode,account=account,ifsc=ifsc,ppic=ppic).save()

    return render(request,'user/membership.html',context=mydict)

##################################################
def blog(request):
    mb = myblog.objects.all().order_by('-id')
    if request.method=="POST":
        s=request.POST.get('search')
        if s is not "":
            mb=myblog.objects.all().filter(Q(bname__icontains=s))
        else:
            return HttpResponse("<script>alert('Please enter to search');location.href='/user/blog/'</script>")
    sdict = {"bdata": mb}
    return render(request,'user/blog.html',context=sdict)

##################################################

def blogdescription(request):
    y=request.GET.get('msg')
    blog = myblog.objects.all().filter(id=y)
    if request.method=="POST":
        s=request.POST.get('newsletter')
        if s is not "":
            blog=myblog.objects.all().filter(Q(newsletter__icontains=s))
        else:
            return HttpResponse("<script>alert('Please enter your email first');location.href='/user/index/'</script>")
    bdict = {"blog":blog}
    return render(request,'user/blogdescription.html',bdict)
##################################################
def login(request):
    if request.method=="POST":
        mobile=request.POST.get('mob')
        password=request.POST.get('password')
        loginme(mobile=mobile,password=password)
    return render(request,'user/login.html')

def volunteer(request):
    volunt = volunteers.objects.all().order_by('-id')
    vdict ={"vdata":volunt}
    return render(request,'user/volunteer.html',context=vdict)

def profile(request):
    my =myprofile.objects.all().order_by('-id')
    mypro ={"profile":my}
    return render(request,'user/profile.html',mypro)

def base(request):
    cp = compaign.objects.all().order_by(-id)
    if request.method=="POST":
        sub=request.POST.get('newsletter')

    newsletter(subscribers=sub)
    mycdict ={"cp":cp,"nl":sub}
    return render(request,'base.html',mycdict)

def search(request):
    return render(request,'user/search.html')

def benefits(request):
    return render(request,'user/benefits.html')