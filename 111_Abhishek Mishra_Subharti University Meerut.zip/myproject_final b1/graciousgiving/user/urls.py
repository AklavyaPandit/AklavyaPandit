from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('home/', views.index),
    path('index/', views.index),
    path('about/', views.about),
    path('contact/', views.contact),
    path('membership/', views.membership),
    path('gallery/', views.gallery),
    path('video/', views.video),
    path('login/', views.login),
    path('donate/', views.donate),
    path('blog/', views.blog),
    path('volunteer/', views.volunteer),
    path('details/', views.videodetails),
    path('profile/', views.profile),
    path('blogdescription/', views.blogdescription),
    path('search/', views.search),
    path('benefits/', views.benefits),
]