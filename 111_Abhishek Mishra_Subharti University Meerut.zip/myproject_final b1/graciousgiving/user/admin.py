from django.contrib import admin
from .models import *
# Register your models here.
class contactusAdmin(admin.ModelAdmin):
    list_display = ("Name","Email","Mobile","Message")

admin.site.register(contactus,contactusAdmin)

class igalleryAdmin(admin.ModelAdmin):
    list_display = ("id","gname","gpic")
admin.site.register(igallery,igalleryAdmin)

class vgalleryAdmin(admin.ModelAdmin):
    list_display = ("id","vname","vid","poster")
admin.site.register(vgallery,vgalleryAdmin)

class vidgalleryAdmin(admin.ModelAdmin):
    list_display = ("id","vtitle","vdes","vidlink","vdate")
admin.site.register(vidgallery,vidgalleryAdmin)
class sliderAdmin(admin.ModelAdmin):
    list_display = ("id","shead","ssubject","sdes","spic")

admin.site.register(slider,sliderAdmin)

class myblogAdmin(admin.ModelAdmin):
    list_display = ("id","bname","bdes","bpic","bdate")
admin.site.register(myblog,myblogAdmin)

class ncityAdmin(admin.ModelAdmin):
    list_display = ("id","cname")
admin.site.register(ncity,ncityAdmin)

class memberAdmin(admin.ModelAdmin):
    list_display = ("id","fname","lname","email","mobile","city","state","country","address","companyaddress","pincode","account","ifsc","ppic")

admin.site.register(member,memberAdmin)

class loginmeAdmin(admin.ModelAdmin):
    list_display = ("mobile","password")

admin.site.register(loginme,loginmeAdmin)

class signupAdmin(admin.ModelAdmin):
    list_display = ("name","email","mobile","password","confirmpassword")

admin.site.register(signup,signupAdmin)

class eventAdmin(admin.ModelAdmin):
    list_display = ("etitle","esubject","edate","epic")

admin.site.register(event,eventAdmin)

class volunteersAdmin(admin.ModelAdmin):
    list_display = ("volunteername","volunteerpost","volunteerpic")

admin.site.register(volunteers,volunteersAdmin)

class donateusAdmin(admin.ModelAdmin):
    list_display = ("id","fname","lname","email","mobile","donation","city","state","country","pincode","address","occupation","screenshot")

admin.site.register(donateus,donateusAdmin)

class myprofileAdmin(admin.ModelAdmin):
    list_display = ("myname","college","course","myid","mypic","mybackground")

admin.site.register(myprofile,myprofileAdmin)

class promiseAdmin(admin.ModelAdmin):
    list_display = ("ptitle","ppic")

admin.site.register(promise,promiseAdmin)

class compaignAdmin(admin.ModelAdmin):
    list_display = ("id","mycompaign")

admin.site.register(compaign,compaignAdmin)

class newsletterAdmin(admin.ModelAdmin):
    list_display = ("id","subscribers")

admin.site.register(newsletter,newsletterAdmin)