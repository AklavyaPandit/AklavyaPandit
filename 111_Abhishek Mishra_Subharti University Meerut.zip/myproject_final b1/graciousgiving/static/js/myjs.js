function match()
{
var fn=document.getElementById('fn')
var req=document.getElementById('req')
if(fn.value=="")
{
fn.style.border="1px solid red"
req.innerText="This field is required"
}
else
{
 fn.style.border=""
}

}